package com.demo.FoodWasteManagementSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodWasteManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoodWasteManagementSystemApplication.class, args);
	}

}
